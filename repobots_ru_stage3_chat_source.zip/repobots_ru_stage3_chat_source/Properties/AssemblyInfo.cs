using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: InternalsVisibleTo("RepoBotsOpenTest")]
[assembly: AssemblyCompany("RepoBots")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("RepoBots")]
[assembly: AssemblyTitle("RepoBots")]
[assembly: AssemblyVersion("1.0.0.0")]
